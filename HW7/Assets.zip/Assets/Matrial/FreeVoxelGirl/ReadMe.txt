Free Voxel Girl ver1.20

The version of unity in which this asset was created is 5.4.5p5.

These models have 560~564 tris.

These models are rigged and animated.

7 Mecanim humanoid animations - Idle, Walk, Run, Jump, Damage, Death, Lose
All animations are animated 60fps.

Please feel free to contact us if you have any problems, questions or suggestions.
Contact : shio.ten4010@gmail.com

Website : http://fire-emotion.com/
Twitter : https://twitter.com/shiouten


---Update---

ver1.20 Added 3 animations - Damage, Death, Lose

ver1.10 Added 2 kinds of color variation

ver1.00 First release